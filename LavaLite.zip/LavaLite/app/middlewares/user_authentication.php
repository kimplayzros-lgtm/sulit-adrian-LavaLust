<?php

return function($method, $params) {
    if (!is_authenticated()) {
        return false;
    }
    return true;
};