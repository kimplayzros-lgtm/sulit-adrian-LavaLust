<?php

return function($method, $params) {
    if (!is_authenticated()) {
        header('location:' . url('/login'));
        exit;
    }
    if (!is_user()) {
        return false;
    }
    return true;
};