<?php
require_login();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= base_url() ?>public/css/styles.css" rel="stylesheet">
    <title>Add Records</title>
</head>

<body class="bg-primary-50 min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 class="text-2xl font-bold text-primary-800 mb-6 text-center">Add New Record</h1>
        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'ckads_last_name' => trim($_POST['ckads_last_name']?? ''),
                'ckads_first_name' => trim($_POST['ckads_first_name']?? ''),
                'ckads_email' => trim($_POST['ckads_email']?? ''),
                'ckads_gender' => trim($_POST['ckads_gender']?? ''),
                'ckads_address' => trim($_POST['ckads_address']?? '')
            ];

            $res = db()->table('d_users')->insert($data);
            if ($res) {
                header('location:'.url('/retrieve'));
            }
        }
        ?>

        <form action="<?= url('/add') ?>" method="post" class="space-y-4">
            <div>
                <label for="ckads_last_name" class="block text-sm font-medium text-primary-700">Last Name</label>
                <input type="text" name="ckads_last_name" id="ckads_last_name" placeholder="Enter Last Name" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <div>
                <label for="ckads_first_name" class="block text-sm font-medium text-primary-700">First Name</label>
                <input type="text" name="ckads_first_name" id="ckads_first_name" placeholder="Enter First Name" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <div>
                <label for="ckads_email" class="block text-sm font-medium text-primary-700">Email</label>
                <input type="email" name="ckads_email" id="ckads_email" placeholder="Enter Email" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <div>
                <label for="ckads_gender" class="block text-sm font-medium text-primary-700">Gender</label>
                <input type="text" name="ckads_gender" id="ckads_gender" placeholder="Enter Gender" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <div>
                <label for="ckads_address" class="block text-sm font-medium text-primary-700">Address</label>
                <textarea name="ckads_address" id="ckads_address" placeholder="Enter Address" rows="3" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required></textarea>
            </div>
            <div>
                <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">Add Record</button>
            </div>
        </form>
        <div class="mt-4 text-center">
            <a href="<?= url('/retrieve') ?>" class="text-primary-600 hover:text-primary-800">View All Records</a>
        </div>
    </div>
</body>

</html>