<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= base_url() ?>public/css/styles.css" rel="stylesheet">
    <title>Retrieve Records</title>
</head>
<body class="bg-primary-50 min-h-screen">
    <?php
    $authenticated = is_authenticated();
    $admin = is_admin();
    $role = $_SESSION['role'] ?? null;
    $success = get_flash('success');
    ?>
    <div class="container mx-auto px-4 py-8">
        <div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div class="space-y-3">
                <div>
                    <h1 class="text-3xl font-bold text-primary-800">All Records</h1>
                    <?php if ($authenticated): ?>
                        <p class="text-sm text-primary-600">Logged in as <strong><?= esc(ucfirst($role)) ?></strong>.</p>
                    <?php else: ?>
                        <p class="text-sm text-primary-600">You are not logged in. <a href="<?= url('/login') ?>" class="text-primary-600 hover:text-primary-900">Login</a> to manage records.</p>
                    <?php endif; ?>
                </div>
                <?php if ($success): ?>
                    <div class="rounded-md bg-green-100 border border-green-300 text-green-800 px-4 py-3 text-sm">
                        <?= esc($success) ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex flex-wrap items-center gap-2">
                <?php if ($authenticated): ?>
                    <a href="<?= url('/logout') ?>" class="inline-block bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md text-sm">Logout</a>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
            <table class="min-w-full divide-y divide-primary-200">
                <thead class="bg-primary-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Last Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">First Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Gender</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Address</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Update</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-primary-700 uppercase tracking-wider">Delete</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-primary-200">
                    <?php
                    $rows = db()->table('d_users')->get_all();
                    foreach($rows as $row): ?>
                    <tr class="hover:bg-primary-50">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-primary-900"><?php echo esc($row['id']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-900"><?php echo esc($row['ckads_last_name']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-900"><?php echo esc($row['ckads_first_name']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-900"><?php echo esc($row['ckads_email']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-900"><?php echo esc($row['ckads_gender']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-900"><?php echo esc($row['ckads_address']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <a href="<?= url('/update/' . $row['id']) ?>" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded-md text-xs">Update</a>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <a href="<?= url('/delete/' . $row['id']) ?>" class="inline-block bg-red-600 hover:bg-red-700 text-white font-bold py-1 px-3 rounded-md text-xs" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-6 text-center">
            <a href="<?= url('/add'); ?>" class="inline-block bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">Add New Record</a>
        </div>
        <div class="mt-6 text-center">
            <a href="<?= url('/login') ?>" class="inline-block bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">Back to Homepage</a>
        </div>
    </div>
</body>
</html>