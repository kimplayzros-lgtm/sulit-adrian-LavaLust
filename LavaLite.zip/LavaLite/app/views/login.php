<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?= base_url() ?>public/css/styles.css" rel="stylesheet">
    <title>Login</title>
</head>
<body class="bg-primary-50 min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
        <h1 class="text-2xl font-bold text-primary-800 mb-6 text-center">Login</h1>
        <?php if ($error = get_flash('error')): ?>
            <div class="mb-4 rounded-md bg-red-100 border border-red-300 text-red-800 px-4 py-3">
                <?= esc($error) ?>
            </div>
        <?php endif; ?>
        <?php if ($success = get_flash('success')): ?>
            <div class="mb-4 rounded-md bg-green-100 border border-green-300 text-green-800 px-4 py-3">
                <?= esc($success) ?>
            </div>
        <?php endif; ?>
        <form action="<?= url('/login') ?>" method="post" class="space-y-4">
            <div>
                <label for="username" class="block text-sm font-medium text-primary-700">Username</label>
                <input type="text" name="username" id="username" placeholder="admin or user" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <div>
                <label for="password" class="block text-sm font-medium text-primary-700">Password</label>
                <input type="password" name="password" id="password" placeholder="Enter password" class="mt-1 block w-full px-3 py-2 border border-primary-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" required>
            </div>
            <button type="submit" class="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2">Login</button>
        </form>
    </div>
</body>
</html>
