<?php
/**
 * All routes here
 */

$router->get('/', 'app/views/homepage');

$router->get('/login', 'app/views/login');
$router->post('/login', function() {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $accounts = [
        'admin' => ['password' => 'admin123', 'role' => 'admin'],
        'user'  => ['password' => 'user123', 'role' => 'user'],
    ];

    if (isset($accounts[$username]) && $accounts[$username]['password'] === $password) {
        $_SESSION['user'] = $username;
        $_SESSION['role'] = $accounts[$username]['role'];
        set_flash('success', 'Logged in successfully as ' . ucfirst($_SESSION['role']) . '.');
        $redirect = $_SESSION['role'] === 'admin' ? '/retrieve' : '/user';
        header('location:' . url($redirect));
        exit;
    }

    set_flash('error', 'Invalid username or password.');
    header('location:' . url('/login'));
    exit;
});

$router->get('/logout', function() {
    session_unset();
    session_destroy();
    header('location:' . url('/login'));
    exit;
});

$router->get('/retrieve', 'app/views/crud/retrieve', ['admin_authorization']);
$router->get('/user', 'app/views/user', ['user_authorization']);
$router->any('/add', 'app/views/crud/add', ['admin_authorization']);
$router->any('/update/{id}', 'app/views/crud/update', ['admin_authorization']);
$router->get('/delete/{id}', function($id) {
    require_admin();

    $res = db()->table('d_users')->where('id', $id)->delete();
    header('location:' . url('/retrieve'));
});